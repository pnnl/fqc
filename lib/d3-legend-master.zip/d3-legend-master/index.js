var d3 = require('d3');

d3.legend = require('./no-extend');

module.exports = d3;
