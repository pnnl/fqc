d3.legend = {
  color: require('./color'),
  size: require('./size'),
  symbol: require('./symbol')
};